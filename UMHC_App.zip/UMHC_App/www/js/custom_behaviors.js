$(document).ready(function() {

	// VARIABLES


	// EVENT HANDLERS
	$('.main-carousel').flickity({
	  cellAlign: 'left',
	  contain: true
	});
	// $(".Thursday .right").trigger(".flickity-prev-next-button");
	$(".back").on("click", function() {
		$(".event").fadeOut(500);
		$(".TA4").fadeOut(500);
		$(".explore").fadeOut(500);
		$(".check").fadeOut(500);
		$(".welcome").fadeOut(500);
		$(".SS1").fadeOut(500);
		$(".SS2").fadeOut(500);
		$(".FS").fadeOut(500);

		$(".FA5").fadeOut(500);
		$(".Net").fadeOut(500);
		$(".Session1").fadeOut(500);
		$(".Sess1").fadeOut(500);
		$(".Session2").fadeOut(500);
		$(".Sess2").fadeOut(500);
		$(".Session3").fadeOut(500);
		$(".Sess3").fadeOut(500);
		$(".Pos").fadeOut(500);
		$(".Lun").fadeOut(500);
		$(".SC").fadeOut(500);
		$(".Session4").fadeOut(500);
		$(".Sess4").fadeOut(500);
		$(".Post").fadeOut(500);
		$(".Session5").fadeOut(500);
		$(".Sess5").fadeOut(500);
		$(".Din").fadeOut(500);
		$(".Movie").fadeOut(500);

		$(".SA6").fadeOut(500);
		$(".Yoga").fadeOut(500);
		$(".ExMeet").fadeOut(500);
		$(".Session6").fadeOut(500);
		$(".Sess6").fadeOut(500);
		$(".Session7").fadeOut(500);
		$(".Sess7").fadeOut(500);
		$(".BusMeet").fadeOut(500);
		$(".Award").fadeOut(500);

	})
	$(".T1").on("click", function() {
		$(".event").fadeIn(500);
		$(".TA4").fadeIn(500);
		$(".explore").fadeIn(500);
	})
	$(".T2").on("click", function() {
		$(".event").fadeIn(500);
		$(".TA4").fadeIn(500);
		$(".check").fadeIn(500);
	})
	$(".T3").on("click", function() {
		$(".event").fadeIn(500);
		$(".TA4").fadeIn(500);
		$(".welcome").fadeIn(500);
	})
	$(".T4").on("click", function() {
		$(".event").fadeIn(500);
		$(".TA4").fadeIn(500);
		$(".SS1").fadeIn(500);
	})
	$(".T5").on("click", function() {
		$(".event").fadeIn(500);
		$(".TA4").fadeIn(500);
		$(".SS2").fadeIn(500);
	})
	$(".T6").on("click", function() {
		$(".event").fadeIn(500);
		$(".TA4").fadeIn(500);
		$(".FS").fadeIn(500);
	})
	$(".F1").on("click", function() {
		$(".event").fadeIn(500);
		$(".FA5").fadeIn(500);
		$(".Net").fadeIn(500);
	})
	$(".F2").on("click", function() {
		$(".event").fadeIn(500);
		$(".FA5").fadeIn(500);
		$(".Session1").fadeIn(500);
		$(".Sess1").fadeIn(500);
	})
	$(".F3").on("click", function() {
		$(".event").fadeIn(500);
		$(".FA5").fadeIn(500);
		$(".Session2").fadeIn(500);
		$(".Sess2").fadeIn(500);
	})
	$(".F4").on("click", function() {
		$(".event").fadeIn(500);
		$(".FA5").fadeIn(500);
		$(".Session3").fadeIn(500);
		$(".Sess3").fadeIn(500);
	})
	$(".F5").on("click", function() {
		$(".event").fadeIn(500);
		$(".FA5").fadeIn(500);
		$(".Pos").fadeIn(500);
	})
	$(".F6").on("click", function() {
		$(".event").fadeIn(500);
		$(".FA5").fadeIn(500);
		$(".Lun").fadeIn(500);
	})
	$(".F7").on("click", function() {
		$(".event").fadeIn(500);
		$(".FA5").fadeIn(500);
		$(".SC").fadeIn(500);
	})
	$(".F8").on("click", function() {
		$(".event").fadeIn(500);
		$(".FA5").fadeIn(500);
		$(".Session4").fadeIn(500);
		$(".Sess4").fadeIn(500);
	})
	$(".F9").on("click", function() {
		$(".event").fadeIn(500);
		$(".FA5").fadeIn(500);
		$(".Post").fadeIn(500);
	})
	$(".F10").on("click", function() {
		$(".event").fadeIn(500);
		$(".FA5").fadeIn(500);
		$(".Session5").fadeIn(500);
		$(".Sess5").fadeIn(500);
	})
	$(".F11").on("click", function() {
		$(".event").fadeIn(500);
		$(".FA5").fadeIn(500);
		$(".Din").fadeIn(500);
	})
	$(".F12").on("click", function() {
		$(".event").fadeIn(500);
		$(".FA5").fadeIn(500);
		$(".Movie").fadeIn(500);
	})
	$(".Sat1").on("click", function() {
		$(".event").fadeIn(500);
		$(".SA6").fadeIn(500);
		$(".Yoga").fadeIn(500);
	})
	$(".Sat2").on("click", function() {
		$(".event").fadeIn(500);
		$(".SA6").fadeIn(500);
		$(".ExMeet").fadeIn(500);
	})
	$(".Sat3").on("click", function() {
		$(".event").fadeIn(500);
		$(".SA6").fadeIn(500);
		$(".Session6").fadeIn(500);
		$(".Sess6").fadeIn(500);
	})
	$(".Sat4").on("click", function() {
		$(".event").fadeIn(500);
		$(".SA6").fadeIn(500);
		$(".Session7").fadeIn(500);
		$(".Sess7").fadeIn(500);
	})
	$(".Sat5").on("click", function() {
		$(".event").fadeIn(500);
		$(".SA6").fadeIn(500);
		$(".BusMeet").fadeIn(500);
	})
	$(".Sat6").on("click", function() {
		$(".event").fadeIn(500);
		$(".SA6").fadeIn(500);
		$(".Award").fadeIn(500);
	})



	// FUNCTIONS


	// INITIALIZATION


});
